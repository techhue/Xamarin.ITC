package com.techhue.intents;

import android.net.Uri;

public class MoonBaseProvider {
    public static Uri CONTENT_URI = Uri.parse("content://moonbases");
}
